// Gemini Library Link Finder - Discovers all conversations from library page
// Returns links to popup which will orchestrate the scraping

(function() {
  console.log('=== AI Chronicle Library Link Finder - ENGAGED ===');
  console.log('Finding all conversations in library...');

  // Verify we're on the library page
  if (!window.location.href.includes('/library')) {
    console.error('Not on library page');
    return {
      success: false,
      error: 'Not on library page. Please navigate to https://aistudio.google.com/library first'
    };
  }

  // Find all conversation links in the library table
  function findConversationLinks() {
    const links = [];

    // Target the table body within the library
    const tableBody = document.querySelector('ms-library-table tbody');

    if (!tableBody) {
      console.error('Could not find library table');
      return links;
    }

    // Find all links with href starting with /prompts/
    const anchorElements = tableBody.querySelectorAll('a[href^="/prompts/"]');

    anchorElements.forEach(anchor => {
      const href = anchor.getAttribute('href');
      const title = anchor.getAttribute('title') || anchor.textContent.trim();

      if (href && title) {
        // Create full URL
        const fullUrl = `https://aistudio.google.com${href}`;

        // Avoid duplicates
        if (!links.find(l => l.fullUrl === fullUrl)) {
          links.push({
            href: href,
            fullUrl: fullUrl,
            title: title.trim()
          });
        }
      }
    });

    return links;
  }

  // Discover all links
  const conversationLinks = findConversationLinks();

  if (conversationLinks.length === 0) {
    console.error('No conversation links found');
    return {
      success: false,
      error: 'No conversations found in library. Make sure the page is fully loaded.'
    };
  }

  console.log(`📚 Found ${conversationLinks.length} conversations`);
  console.log('Conversations:', conversationLinks.map(l => l.title));

  // Return the links to popup.js
  return {
    success: true,
    links: conversationLinks,
    count: conversationLinks.length
  };

})();
