// Background service worker for AI Chronicle

// Global stop flag
let shouldStopScraping = false;

// Listen for installation
chrome.runtime.onInstalled.addListener(() => {
  console.log('[AI Chronicle] Extension installed');
});

// Initialize on startup
chrome.runtime.onStartup.addListener(() => {
  console.log('[AI Chronicle] Extension started');
});

// Handle messages from popup and content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('[AI Chronicle] Background received message:', request);

  // Handle async responses
  (async () => {
    try {
      switch(request.type) {
        case 'START_LIBRARY_SCRAPING':
          console.log('[AI Chronicle] Starting library scraping orchestration');
          shouldStopScraping = false; // Reset stop flag
          await startLibraryScraping(request.links, request.format, request.tabId, request.startFrom || 1);
          sendResponse({ success: true });
          break;

        case 'STOP_LIBRARY_SCRAPING':
          console.log('[AI Chronicle] Stop request received');
          shouldStopScraping = true;
          sendResponse({ success: true });
          break;

        default:
          sendResponse({ success: true });
      }
    } catch (error) {
      console.error('[AI Chronicle] Message handling error:', error);
      sendResponse({ success: false, error: error.message });
    }
  })();

  return true; // Keep message channel open for async response
});

// Library scraping orchestration - runs in background
async function startLibraryScraping(links, format, originalTabId, startFrom = 1) {
  const startIndex = startFrom - 1; // Convert to 0-based index
  console.log(`[AI Chronicle] Orchestrating ${links.length} conversations (starting from #${startFrom})`);

  const results = {
    total: links.length,
    completed: 0,
    failed: 0,
    skipped: startIndex,
    conversations: []
  };

  for (let i = startIndex; i < links.length; i++) {
    // Check stop flag
    if (shouldStopScraping) {
      console.log(`\n⛔ STOP REQUESTED - Halting at conversation ${i + 1}/${links.length}`);
      break;
    }

    const conv = links[i];
    console.log(`\n========================================`);
    console.log(`[${i + 1}/${links.length}] Processing: ${conv.title}`);
    console.log(`URL: ${conv.fullUrl}`);

    try {
      // Open conversation in ACTIVE tab (foreground) so we can see it working
      console.log('Opening conversation in foreground...');
      const newTab = await chrome.tabs.create({
        url: conv.fullUrl,
        active: true  // FOREGROUND - must be visible for dynamic DOM
      });
      console.log(`Tab created with ID: ${newTab.id}`);

      // Wait for page to load and render
      console.log('Waiting for page to load (5 seconds)...');
      await new Promise(resolve => setTimeout(resolve, 5000));

      // Inject format and title variables
      console.log('Injecting format and title variables...');
      await chrome.scripting.executeScript({
        target: { tabId: newTab.id },
        func: (selectedFormat, conversationTitle) => {
          window.__AI_CHRONICLE_FORMAT__ = selectedFormat;
          window.__AI_CHRONICLE_TITLE__ = conversationTitle;
        },
        args: [format, conv.title]
      });

      // Run the main scraper
      console.log('Running scraper...');
      const [scraperResult] = await chrome.scripting.executeScript({
        target: { tabId: newTab.id },
        files: ['scripts/google-ai-studio/gemini-scraper.js']
      });

      // Wait for scraper to complete - poll for completion
      console.log('Waiting for scraper to complete...');
      const startTime = Date.now();
      const maxWaitTime = 90000; // 90 seconds max
      let completed = false;

      while (!completed && (Date.now() - startTime) < maxWaitTime) {
        // Wait 2 seconds between checks
        await new Promise(resolve => setTimeout(resolve, 2000));

        try {
          // Check if scraper is done by checking window variable
          const [checkResult] = await chrome.scripting.executeScript({
            target: { tabId: newTab.id },
            func: () => {
              return window.turboConversationData?.success || false;
            }
          });

          if (checkResult && checkResult.result === true) {
            completed = true;
            const elapsed = Math.round((Date.now() - startTime) / 1000);
            console.log(`✓ Scraper completed in ${elapsed} seconds`);
          }
        } catch (e) {
          // Tab might be closed or not ready, ignore
        }
      }

      if (!completed) {
        console.log('⚠️ Timeout reached, moving on...');
      }

      // Close the tab
      console.log('Closing tab...');
      try {
        // Check if tab still exists first
        const tab = await chrome.tabs.get(newTab.id);
        if (tab) {
          await chrome.tabs.remove(newTab.id);
          console.log('Tab closed successfully');
        }
      } catch (closeError) {
        console.log('Tab already closed or unavailable:', closeError.message);
      }

      results.completed++;
      results.conversations.push({
        title: conv.title,
        url: conv.fullUrl,
        status: 'completed'
      });

      console.log(`✅ Completed: ${conv.title}`);
      console.log(`Progress: ${results.completed}/${links.length} completed, ${results.failed} failed`);

      // Update original tab badge or notification
      try {
        chrome.action.setBadgeText({
          text: `${results.completed}/${links.length}`,
          tabId: originalTabId
        });
        chrome.action.setBadgeBackgroundColor({ color: '#4CAF50' });
      } catch (e) {
        // Ignore if tab is closed
      }

      // Brief pause between conversations to see the download happen
      console.log('Pausing before next conversation (2 seconds)...');
      await new Promise(resolve => setTimeout(resolve, 2000));

    } catch (error) {
      console.error(`❌ Error processing ${conv.title}:`, error);
      results.failed++;
      results.conversations.push({
        title: conv.title,
        url: conv.fullUrl,
        status: 'failed',
        error: error.message
      });
    }
  }

  // Final summary
  console.log('\n' + '='.repeat(60));
  if (shouldStopScraping) {
    console.log('⛔ LIBRARY SCRAPING STOPPED BY USER');
  } else {
    console.log('🎉 LIBRARY SCRAPING COMPLETE!');
  }
  console.log('='.repeat(60));
  console.log(`Total: ${results.total}`);
  console.log(`⏭️  Skipped: ${results.skipped}`);
  console.log(`✅ Completed: ${results.completed}`);
  console.log(`❌ Failed: ${results.failed}`);

  // Show notification
  try {
    const title = shouldStopScraping ?
      'AI Chronicle - Batch Scraping Stopped' :
      'AI Chronicle - Batch Scraping Complete';
    const message = shouldStopScraping ?
      `Stopped by user.\nCompleted: ${results.completed}\nFailed: ${results.failed}\n\nCheck your downloads folder.` :
      `Completed: ${results.completed}\nFailed: ${results.failed}\n\nCheck your downloads folder.`;

    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'images/white-feather.png',
      title: title,
      message: message,
      priority: 2
    });

    // Clear badge
    chrome.action.setBadgeText({ text: '' });
  } catch (e) {
    console.error('Error showing notification:', e);
  }

  // Reset stop flag
  shouldStopScraping = false;

  return results;
}