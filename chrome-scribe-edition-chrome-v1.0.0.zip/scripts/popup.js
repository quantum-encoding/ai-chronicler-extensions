// Popup script for AI Chronicle

let scrapedData = null;

// Update UI elements
const statusEl = document.getElementById('status');
const statusTextEl = document.getElementById('status-text');
const resultsEl = document.getElementById('results');
const messageCountEl = document.getElementById('messageCount');
const charCountEl = document.getElementById('charCount');
const scriptSelectEl = document.getElementById('scriptSelect');

// Buttons
const scrapeBtn = document.getElementById('scrapeBtn');
const autoScrollBtn = document.getElementById('autoScrollBtn');
const stopBtn = document.getElementById('stopBtn');
const universalBtn = document.getElementById('universalBtn');
const debugBtn = document.getElementById('debugBtn');
const copyBtn = document.getElementById('copyBtn');
const downloadBtn = document.getElementById('downloadBtn');

// Batch options
const batchOptionsEl = document.getElementById('batchOptions');
const startFromInputEl = document.getElementById('startFromInput');

// Update status
function updateStatus(text, type = 'normal') {
  statusTextEl.textContent = text;
  statusEl.className = `status ${type}`;
}

// Format conversation based on selected format
function formatConversation(data, format) {
  const { messages, platform, url, timestamp } = data;
  
  if (format === 'json') {
    return JSON.stringify(data, null, 2);
  }
  
  let output = '';
  
  if (format === 'md') {
    output += `# AI Conversation Log\n\n`;
    output += `**Platform:** ${platform}\n`;
    output += `**URL:** ${url}\n`;
    output += `**Scraped:** ${new Date(timestamp).toLocaleString()}\n`;
    output += `**Messages:** ${messages.length}\n\n`;
    output += `---\n\n`;
    
    messages.forEach((msg, i) => {
      const role = msg.role.charAt(0).toUpperCase() + msg.role.slice(1);
      output += `## ${role}\n\n`;
      output += `${msg.content}\n\n`;
      if (i < messages.length - 1) {
        output += `---\n\n`;
      }
    });
  } else {
    // Plain text format
    output += `AI Conversation Log\n`;
    output += `Platform: ${platform}\n`;
    output += `URL: ${url}\n`;
    output += `Scraped: ${new Date(timestamp).toLocaleString()}\n`;
    output += `Messages: ${messages.length}\n\n`;
    output += `${'='.repeat(50)}\n\n`;
    
    messages.forEach((msg, i) => {
      const role = msg.role.toUpperCase();
      output += `${role}:\n${msg.content}\n\n`;
      if (i < messages.length - 1) {
        output += `${'-'.repeat(50)}\n\n`;
      }
    });
  }
  
  return output;
}

// Scrape conversation
async function scrapeConversation(autoScroll = false) {
  updateStatus('Starting capture...', 'scraping');
  scrapeBtn.disabled = true;
  autoScrollBtn.disabled = true;
  
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const selectedScript = scriptSelectEl.value;
    
    // Check platform and script selection
    if (tab.url.includes('chatgpt.com') && selectedScript === 'chatgpt') {
      // Use ChatGPT scrapers
      updateStatus('Using ChatGPT scraper...', 'scraping');
      
      // Get the selected format
      const format = document.querySelector('input[name="format"]:checked').value;
      
      // First inject the script, then send a message with the format
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: (selectedFormat) => {
          window.__AI_CHRONICLE_FORMAT__ = selectedFormat;
        },
        args: [format]
      });
      
      // Now inject and execute the appropriate scraper
      const scraperFile = autoScroll ? 'scripts/chat-gpt/chatgpt-auto-capture.js' : 'scripts/chat-gpt/chatgpt-scraper-enhanced.js';
      console.log(`Using scraper: ${scraperFile}`);

      const [result] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: [scraperFile]
      });
      
      // ChatGPT scrapers auto-download, so just show success
      updateStatus('Capture complete! Check your downloads folder.', 'success');
      resultsEl.style.display = 'none';

    } else if (tab.url.includes('aistudio.google.com') && selectedScript === 'gemini') {
      // Get the selected format
      const format = document.querySelector('input[name="format"]:checked').value;

      // Check if we're on library page and autoScroll is enabled
      if (autoScroll && tab.url.includes('/library')) {
        // Library orchestration mode - scrape all conversations
        updateStatus('Finding conversations in library...', 'scraping');

        // Inject the link finder
        const [linkResult] = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['scripts/google-ai-studio/gemini-library-orchestrator.js']
        });

        if (!linkResult || !linkResult.result || !linkResult.result.success) {
          const error = linkResult?.result?.error || 'Failed to find conversations';
          updateStatus(`Error: ${error}`, 'error');
          return;
        }

        const { links, count } = linkResult.result;
        console.log(`Found ${count} conversations to scrape`);

        // Confirm with user
        const userConfirm = confirm(
          `Found ${count} conversation${count > 1 ? 's' : ''} in library.\n\n` +
          `This will:\n` +
          `1. Open each conversation in a new tab\n` +
          `2. Run the scraper and download\n` +
          `3. Close the tab and move to next\n\n` +
          `This may take several minutes.\n\n` +
          `Continue?`
        );

        if (!userConfirm) {
          updateStatus('Cancelled by user', 'normal');
          return;
        }

        // Get startFrom value
        const startFrom = parseInt(startFromInputEl.value) || 1;
        const actualStart = Math.max(1, Math.min(startFrom, count));

        // Send the job to background script (so it keeps running even if popup closes)
        updateStatus(`Starting batch scrape from conversation ${actualStart}...`, 'scraping');
        console.log(`Delegating scraping to background script...`);

        // Show stop button, hide batch buttons
        stopBtn.style.display = 'flex';
        autoScrollBtn.style.display = 'none';
        scrapeBtn.disabled = true;

        // Send message to background script
        chrome.runtime.sendMessage({
          type: 'START_LIBRARY_SCRAPING',
          links: links,
          format: format,
          tabId: tab.id,
          startFrom: actualStart
        }, (response) => {
          if (response && response.success) {
            console.log('Background script started successfully');
          } else {
            console.error('Failed to start background script:', response);
          }
        });

        // Show info to user
        alert(
          `Batch scraping started!\n\n` +
          `${count} conversations will be scraped in the background.\n\n` +
          `You can:\n` +
          `• Close this popup - scraping continues\n` +
          `• Watch the extension badge for progress\n` +
          `• Check console logs for details\n` +
          `• You'll get a notification when complete\n\n` +
          `Downloads will appear in your downloads folder.`
        );

        updateStatus(`Batch scraping ${count} conversations in background...`, 'success');

      } else {
        // Single conversation scrape
        updateStatus('Using Gemini scraper...', 'scraping');

        // First inject the script, then send a message with the format
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: (selectedFormat) => {
            window.__AI_CHRONICLE_FORMAT__ = selectedFormat;
          },
          args: [format]
        });

        // Use the main gemini scraper
        const scraperFile = 'scripts/google-ai-studio/gemini-scraper.js';
        console.log(`Using scraper: ${scraperFile}`);

        const [result] = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: [scraperFile]
        });

        // The scraper will return the data
        if (result && result.result) {
          scrapedData = result.result;
          const charCount = scrapedData.output.length;
          messageCountEl.textContent = scrapedData.stats.messages;
          charCountEl.textContent = charCount.toLocaleString();
          resultsEl.style.display = 'block';
          updateStatus('Capture complete!', 'success');
        } else {
          updateStatus('Capture complete! Check your downloads folder.', 'success');
          resultsEl.style.display = 'none';
        }
      }

    } else {
      // Use the original content script for other platforms
      const response = await chrome.tabs.sendMessage(tab.id, {
        action: autoScroll ? 'autoScrollScrape' : 'scrape'
      });
      
      if (response.error) {
        updateStatus(`Error: ${response.error}`, 'error');
        return;
      }
      
      scrapedData = response;
      
      // Update UI with results
      const charCount = response.messages.reduce((sum, msg) => sum + msg.content.length, 0);
      messageCountEl.textContent = response.messages.length;
      charCountEl.textContent = charCount.toLocaleString();
      
      resultsEl.style.display = 'block';
      updateStatus('Scraping complete!', 'success');
    }
    
  } catch (error) {
    console.error('Scraping error:', error);
    updateStatus('Failed to scrape conversation', 'error');
  } finally {
    scrapeBtn.disabled = false;
    autoScrollBtn.disabled = false;
  }
}

// Copy to clipboard
async function copyToClipboard() {
  if (!scrapedData) return;
  
  const format = document.querySelector('input[name="format"]:checked').value;
  const formatted = formatConversation(scrapedData, format);
  
  try {
    await navigator.clipboard.writeText(formatted);
    updateStatus('Copied to clipboard!', 'success');
  } catch (error) {
    console.error('Copy error:', error);
    updateStatus('Failed to copy', 'error');
  }
}

// Download file
function downloadFile() {
  if (!scrapedData) return;
  
  const format = document.querySelector('input[name="format"]:checked').value;
  const formatted = formatConversation(scrapedData, format);
  
  const timestamp = new Date().toISOString().split('T')[0];
  const filename = `ai-conversation-${timestamp}.${format}`;
  
  const blob = new Blob([formatted], { 
    type: format === 'json' ? 'application/json' : 'text/plain' 
  });
  
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
  
  updateStatus('Downloaded successfully!', 'success');
}


// Event listeners
scrapeBtn.addEventListener('click', () => scrapeConversation(false));
autoScrollBtn.addEventListener('click', () => scrapeConversation(true));
stopBtn.addEventListener('click', () => {
  // Send stop message to background
  chrome.runtime.sendMessage({
    type: 'STOP_LIBRARY_SCRAPING'
  }, (response) => {
    console.log('Stop request sent');
    updateStatus('Stopping batch scrape...', 'normal');

    // Restore buttons
    stopBtn.style.display = 'none';
    autoScrollBtn.style.display = 'flex';
    scrapeBtn.disabled = false;
  });
});
copyBtn.addEventListener('click', copyToClipboard);
downloadBtn.addEventListener('click', downloadFile);

// Initialize extension when popup opens
document.addEventListener('DOMContentLoaded', async () => {
  // Check if we're on a supported site and update dropdown
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const url = tabs[0].url;

    // Auto-select the appropriate script based on URL
    if (url.includes('aistudio.google.com')) {
      scriptSelectEl.value = 'gemini';
      scrapeBtn.disabled = false;
      autoScrollBtn.disabled = false;

      // Show batch options if on library page
      if (url.includes('/library')) {
        batchOptionsEl.style.display = 'block';
      }
    } else if (url.includes('chat.openai.com') || url.includes('chatgpt.com')) {
      scriptSelectEl.value = 'chatgpt';
      updateStatus('Ready to scrape ChatGPT', 'normal');
      scrapeBtn.disabled = false;
      autoScrollBtn.disabled = false;
    } else {
      updateStatus('Navigate to an AI chat to scrape', 'error');
      scrapeBtn.disabled = true;
      autoScrollBtn.disabled = true;
    }
  });
});

// Handle script selection changes
scriptSelectEl.addEventListener('change', () => {
  const selectedScript = scriptSelectEl.value;
  if (selectedScript) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const url = tabs[0].url;
      if (url.includes('aistudio.google.com') && selectedScript === 'gemini') {
        updateStatus('Ready to scrape', 'normal');
        scrapeBtn.disabled = false;
        autoScrollBtn.disabled = false;
      } else if ((url.includes('chat.openai.com') || url.includes('chatgpt.com')) && selectedScript === 'chatgpt') {
        updateStatus('Ready to scrape ChatGPT', 'normal');
        scrapeBtn.disabled = false;
        autoScrollBtn.disabled = false;
      }
    });
  }
});
// ============================================================================
// TAB SWITCHING
// ============================================================================

document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const tab = btn.dataset.tab;

    // Update active tab button
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    // Update active tab content
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    document.getElementById(`${tab}Tab`).classList.add('active');
  });
});
